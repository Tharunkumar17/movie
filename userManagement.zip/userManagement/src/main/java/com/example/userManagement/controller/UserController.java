package com.example.userManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.userManagement.dto.UserDto;
import com.example.userManagement.entity.User;
import com.example.userManagement.service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	// 1.Get all users 
	@GetMapping("/users")
	public List<User> getAllUsers(){
		List<User> list = userService.getAllUsers();
		return list;
	}
	
	// 2.get user details by id.
	@GetMapping("/users/{mobileNo}")
	public UserDto getUserByMobileNo(@PathVariable long mobileNo) {
		return userService.getUserByMobileNo(mobileNo);
	}
	
	// 3.add user Details 
	@PostMapping("/users")
	public UserDto createUser(@RequestBody UserDto userDto) {
		return userService.createUser(userDto);
	}
	
	// 4.Delete user Details 
	@DeleteMapping("/users/{userId}")
	public String deleteUserDetails(@PathVariable int userId) {
		userService.deleteUserDetails(userId);
		return "User with id " + userId + " has been deleted successfully.";
	}

}
