package com.example.userManagement.dto;

import java.util.Objects;

public class UserDto {
	private String name;
	private int age;
	private long mobileNo;
	private String emailId;
	public UserDto() {
		super();
	}
	public UserDto(String name, int age, long mobileNo, String emailId) {
		super();
		this.name = name;
		this.age = age;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	@Override
	public String toString() {
		return "UserDto [name=" + name + ", age=" + age + ", moblieNo=" + mobileNo + ", emailId=" + emailId + "]";
	}
	@Override
	public int hashCode() {
		return Objects.hash(age, emailId, mobileNo, name);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		UserDto other = (UserDto) obj;
		return age == other.age && Objects.equals(emailId, other.emailId) && mobileNo == other.mobileNo
				&& Objects.equals(name, other.name);
	}
	
	
	

}
