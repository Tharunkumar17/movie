package com.example.userManagement.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.userManagement.dto.UserDto;
import com.example.userManagement.entity.User;
import com.example.userManagement.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private UserRepository userRepository;
	
	
	//1.Getting all users.
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	// 2.Get user details by mobile number
	public UserDto getUserByMobileNo(long mobileNo) {
		Optional<User> userdetils = userRepository.findByMobileNo(mobileNo);
		if (userdetils.isEmpty()) {
			throw new RuntimeException("User not found with mobile number: " + mobileNo);
			}
		return mapper.map(userdetils.get(), UserDto.class);
	}

	// 3.Adding user
	public UserDto createUser(UserDto userDto) {
		User m = mapper.map(userDto, User.class);
		if (m != null) {
		    userRepository.save(m);
		  }
		return mapper.map(m, UserDto.class);
	}

	// delete user details
	public void deleteUserDetails(int userId) {
		userRepository.deleteById(userId);	
	}
	
	
	
	
	
	

}
