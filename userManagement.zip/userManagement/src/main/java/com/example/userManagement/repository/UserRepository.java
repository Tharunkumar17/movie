package com.example.userManagement.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.userManagement.entity.User;


public interface UserRepository extends JpaRepository<User, Integer> {
	Optional<User> findByMobileNo(long mobileNo);
	
	@Override
	List<User> findAll();
}
