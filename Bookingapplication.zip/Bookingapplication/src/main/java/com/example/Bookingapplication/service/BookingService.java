package com.example.Bookingapplication.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.example.Bookingapplication.dto.BookingDto;
import com.example.Bookingapplication.entity.Booking;
import com.example.Bookingapplication.entity.Movie;
import com.example.Bookingapplication.entity.User;
import com.example.Bookingapplication.repository.BookingRepository;
import com.example.Bookingapplication.repository.MovieRepository;
import com.example.Bookingapplication.repository.UserRepository;

public class BookingService {
	@Autowired
    private BookingRepository bookingRepository;
	@Autowired
    private MovieRepository movieRepository;
	@Autowired
    private UserRepository userRepository;

    private final String userServiceUrl = "http://user-service/api/users/";
    private final String movieServiceUrl = "http://movie-service/api/movies/";

    @Autowired
    private RestTemplate restTemplate;

    // Method to create a new booking
    public BookingDto createBooking(BookingDto bookingDto) {
        // Fetch user data using REST API
        User user = restTemplate.getForObject(userServiceUrl + bookingDto.getUserId(), User.class);

        // Fetch movie data using REST API
        Movie movie = restTemplate.getForObject(movieServiceUrl + bookingDto.getMovieId(), Movie.class);

        // Create and set booking details
        Booking booking = new Booking();
        booking.setBookingTime(LocalDateTime.now());
        booking.setSeats(bookingDto.getSeats());
        booking.setTotalPrice(calculateTotalPrice(bookingDto.getSeats()));
        booking.setStatus("CONFIRMED");

        // Set movie and user from the fetched data
//        booking.setMovie(new Movie(movie.getMovieId(), movie.getMovieName()));
//        booking.setUser(new User(user.getUserId(), user.getName())); 

        Optional<Movie> optionalMovie = movieRepository.findById(bookingDto.getMovieId());
        Movie movie1 = optionalMovie.orElseThrow(() -> new RuntimeException("Movie not found"));

        // Try to find the user by their ID
        Optional<User> optionalUser = userRepository.findById(bookingDto.getUserId());
        User user1 = optionalUser.orElseThrow(() -> new RuntimeException("User not found"));

        // Set the fetched Movie and User entities to the Booking
        booking.setMovie(movie1);
        booking.setUser(user1);
        booking = bookingRepository.save(booking);

        // Set the bookingDTO values
        bookingDto.setBookingId(booking.getBookingId());
        bookingDto.setMovieName(movie1.getMovieName());
        bookingDto.setShowTime(movie1.getDateTime());  // Add the showTime to the response
        bookingDto.setUserName(user1.getName());

        return bookingDto;
    }

    // Calculate the total price (e.g., $10 per seat)
    private double calculateTotalPrice(int seats) {
        return 10.0 * seats; // Example price per seat
    }

    // Method to get all bookings
    public List<BookingDto> getAllBookings() {
        // Fetch all bookings and return the list of BookingDTOs
        List<Booking> bookings = bookingRepository.findAll();
        List<BookingDto> bookingDTOs = new ArrayList<>();
        for (Booking booking : bookings) {
            BookingDto bookingDto = new BookingDto();
            bookingDto.setBookingId(booking.getBookingId());
            bookingDto.setSeats(booking.getSeats());
            bookingDto.setTotalPrice(booking.getTotalPrice());
            bookingDto.setStatus(booking.getStatus());
            bookingDto.setUserId(booking.getUser().getUserId());
            bookingDto.setUserName(booking.getUser().getName());
            bookingDto.setMovieId(booking.getMovie().getMovieId());
            bookingDto.setMovieName(booking.getMovie().getMovieName());
            bookingDto.setShowTime(booking.getMovie().getDateTime());
            bookingDTOs.add(bookingDto);
        }
        return bookingDTOs;
    }
}
