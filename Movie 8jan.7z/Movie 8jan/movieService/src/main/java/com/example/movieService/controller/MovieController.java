package com.example.movieService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.movieService.dto.Moviedto;
import com.example.movieService.service.MovieService;


@RestController
public class MovieController {
	@Autowired
	private MovieService movieService;
	
	@GetMapping("/movies")
	public List<Moviedto> alldetails() {
		List<Moviedto> list = movieService.allDetails();
		return list;
	}
	
	@GetMapping("/movies/{movieId}")
	public Moviedto getMovieDetailsById(@PathVariable int movieId){
		return movieService.getMovieDetailsById(movieId);
	}
	
	@PostMapping("/movies")
	public Moviedto addMovieDetails(@RequestBody Moviedto moviedto) {
		//TODO: process POST request
		
		return movieService.addMovieDetails(moviedto);
	}
	
	@PutMapping("/movies/{movieId}")
	public Moviedto updateMovieDetails(@PathVariable int movieId, @RequestBody Moviedto moviedto) {
		return movieService.updateMovieDetails(movieId, moviedto);
	}
	
	@DeleteMapping("/movies/{movieId}")
	public void deleteMovieDetails(@PathVariable int movieId) {
		movieService.deleteMovieDetails(movieId);
	}
	

}
