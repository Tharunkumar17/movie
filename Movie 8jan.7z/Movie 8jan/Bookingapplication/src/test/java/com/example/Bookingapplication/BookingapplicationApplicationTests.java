package com.example.Bookingapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
