package com.example.userManagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.userManagement.entity.User;
import com.example.userManagement.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	private UserRepository userRepository;
	
	
	//1.Getting all users.
	public List<User> getAllUsers() {
		return userRepository.findAll();
	}

	// 2.Get user details by mobile number
	public User getUserByMobileNo(long mobileNo) {
        return userRepository.findByMobileNo(mobileNo);
    }


	// 3.Adding user
	public User createUser(User user) {
        return userRepository.save(user);
    }


	// delete user details
	public void deleteUserDetails(int userId) {
		userRepository.deleteById(userId);	
	}

	public User getUserWithIdUser(int userId) {
        // Return user if found, otherwise return null
        return userRepository.findById(userId).orElse(null);
    }
	
}
