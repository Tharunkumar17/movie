package com.example.Bookingapplication.entity;



import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {
    @Id
    private int userId;
    private String name;
    private int age;
    private long mobileNo;
    private String emailId;

    // No-argument constructor required by JPA
    public User() {
        super();
    }

    // Constructor with arguments for easy object creation
    public User(int userId, String name, int age, long mobileNo, String emailId) {
        super();
        this.userId = userId;
        this.name = name;
        this.age = age;
        this.mobileNo = mobileNo;
        this.emailId = emailId;
    }

    // Getters and Setters
    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public long getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(long mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    // Override toString() for better object representation
    @Override
    public String toString() {
        return "User [userId=" + userId + ", name=" + name + ", age=" + age + ", mobileNo=" + mobileNo + ", emailId="
                + emailId + "]";
    }

    // Override equals() and hashCode() based on userId, because it's the unique identifier
    @Override
    public int hashCode() {
        return Objects.hash(userId);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        User other = (User) obj;
        return userId == other.userId;  // Comparing by userId, which is unique
    }
}
