
package com.example.Bookingapplication.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Bookingapplication.client.MovieFeignClient;
import com.example.Bookingapplication.client.UserFeignClient;
import com.example.Bookingapplication.dto.BookingDto;
import com.example.Bookingapplication.entity.Booking;
import com.example.Bookingapplication.entity.Movie;
import com.example.Bookingapplication.entity.User;
import com.example.Bookingapplication.repository.BookingRepository;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private UserFeignClient userFeignClient;

    @Autowired
    private MovieFeignClient movieFeignClient;

    
//    private final String userServiceUrl = "http://localhost:8081/users/id/";
//    private final String movieServiceUrl = "http://localhost:9393/movies/";

    // Method to create a new booking
    public BookingDto createBooking(BookingDto bookingDto) {
        // Fetch user data using REST API
    	User user = userFeignClient.getUserById(bookingDto.getUserId());
        if (user == null) {
            throw new RuntimeException("User not found for ID: " + bookingDto.getUserId());
        }

        // Fetch movie data 
        Movie movie = movieFeignClient.getMovieById(bookingDto.getMovieId());
        if (movie == null) {
            throw new RuntimeException("Movie not found for ID: " + bookingDto.getMovieId());
        }

        // set booking details
        Booking booking = new Booking();
        booking.setBookingTime(LocalDateTime.now());
        booking.setSeats(bookingDto.getSeats());
        booking.setTotalPrice(calculateTotalPrice(bookingDto.getSeats()));
        booking.setStatus("CONFIRMED");

        // -------Set movie and user from the fetched 
        booking.setMovie(movie);
        booking.setUser(user);

      
        booking = bookingRepository.save(booking);

        
        bookingDto.setBookingId(booking.getBookingId());
        bookingDto.setMovieName(movie.getMovieName());
        bookingDto.setShowTime(movie.getDateTime()); 
        bookingDto.setUserName(user.getName()); 

        return bookingDto;
    }

    
    private double calculateTotalPrice(int seats) {
        return 100.0 * seats;
    }

    // by bookingId (GET request)
    public BookingDto getBookingById(int bookingId) {
    	Optional<Booking> optionalBooking = bookingRepository.findById(bookingId);
        Booking booking = optionalBooking.orElseThrow(() -> new RuntimeException("Booking not found"));


        
        BookingDto bookingDto = new BookingDto();
        bookingDto.setBookingId(booking.getBookingId());
        bookingDto.setSeats(booking.getSeats());
        bookingDto.setTotalPrice(booking.getTotalPrice());
        bookingDto.setStatus(booking.getStatus());
        bookingDto.setUserId(booking.getUser().getUserId());
        bookingDto.setUserName(booking.getUser().getName());
        bookingDto.setMovieId(booking.getMovie().getMovieId());
        bookingDto.setMovieName(booking.getMovie().getMovieName());
        bookingDto.setShowTime(booking.getMovie().getDateTime());

        return bookingDto;
    }

    
    public List<BookingDto> getAllBookings() {
        List<Booking> bookings = bookingRepository.findAll();
        List<BookingDto> bookingDTOs = new ArrayList<>();

        for (Booking booking : bookings) {
            
        	User user = userFeignClient.getUserById(booking.getUser().getUserId());
            Movie movie = movieFeignClient.getMovieById(booking.getMovie().getMovieId());
            
            if (user == null || movie == null) {
                continue; 
            }


            BookingDto bookingDto = new BookingDto();
            bookingDto.setBookingId(booking.getBookingId());
            bookingDto.setSeats(booking.getSeats());
            bookingDto.setTotalPrice(booking.getTotalPrice());
            bookingDto.setStatus(booking.getStatus());
            bookingDto.setUserId(user.getUserId());
            bookingDto.setUserName(user.getName());
            bookingDto.setMovieId(movie.getMovieId());
            bookingDto.setMovieName(movie.getMovieName());
            bookingDto.setShowTime(movie.getDateTime());

            bookingDTOs.add(bookingDto);
        }

        return bookingDTOs;
    }
}




