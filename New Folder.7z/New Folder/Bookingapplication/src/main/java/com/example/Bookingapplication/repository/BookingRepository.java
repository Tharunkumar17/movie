package com.example.Bookingapplication.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Bookingapplication.entity.Booking;

public interface BookingRepository extends JpaRepository<Booking, Integer> {

}
