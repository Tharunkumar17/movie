package com.example.movieService.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.movieService.dto.Moviedto;
import com.example.movieService.entity.Movie;
import com.example.movieService.repository.MovieRepository;

@Service
public class MovieService {
	@Autowired
	private MovieRepository movieRepository;
	
	@Autowired
	private ModelMapper mapper;
	
	public List<Moviedto> allDetails(){
		List<Movie> moviesList = movieRepository.findAll();
		List<Moviedto> moviesDtoList = new ArrayList<>();
		for (Movie movie: moviesList ) {
			moviesDtoList.add(mapper.map(movie, Moviedto.class));
		}
		return moviesDtoList;
	}

	public Moviedto getMovieDetailsById(int movieId) {
		// TODO Auto-generated method stub
		Optional<Movie> optional = movieRepository.findById(movieId);
		if (optional.isEmpty()) {
			throw new RuntimeException();
		}
			return mapper.map(optional.get(), Moviedto.class);
		
	}
	
	public Moviedto addMovieDetails(Moviedto moviedto) {
		Movie m = mapper.map(moviedto, Movie.class);
		movieRepository.save(m);
		
		return mapper.map(m, Moviedto.class);
	}
	
	public Moviedto updateMovieDetails(int movieId, Moviedto moviedto) {
		Optional<Movie> existingMovie = movieRepository.findById(movieId);
		if (existingMovie.isEmpty()) {
			throw new RuntimeException("Movie Details not Found with Id : "+movieId);
		}
		Movie movie = existingMovie.get();
		mapper.map(moviedto, movie);
		Movie updted = movieRepository.save(movie);
		return mapper.map(updted, Moviedto.class);
	}

	public void deleteMovieDetails(int movieId) {
		// TODO Auto-generated method stub
		movieRepository.deleteById(movieId);
		
	}
}
