package com.example.movieService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.movieService.entity.Movie;


public interface MovieRepository extends JpaRepository<Movie, Integer> {

}
