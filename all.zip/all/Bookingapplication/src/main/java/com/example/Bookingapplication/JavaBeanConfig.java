package com.example.Bookingapplication;



import org.modelmapper.ModelMapper;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import com.example.Bookingapplication.service.BookingService;

@Configuration
public class JavaBeanConfig {
	@Bean
	public BookingService bookingService() {
		return new BookingService();
	}
	
	@Bean
	public ModelMapper modelMapper() {
		return new ModelMapper();
	}
	
	@Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
