package com.example.Bookingapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Bookingapplication.dto.BookingDto;
import com.example.Bookingapplication.service.BookingService;

@RestController 
@RequestMapping("/api/bookings")
public class BookingController {
	
	@Autowired 
	private BookingService bookingService;
	
	@PostMapping
    public BookingDto createBooking(@RequestBody BookingDto bookingDto) {
        return bookingService.createBooking(bookingDto);
    }

    // Endpoint to get all bookings
    @GetMapping
    public List<BookingDto> getAllBookings() {
        return bookingService.getAllBookings();
    }
}
