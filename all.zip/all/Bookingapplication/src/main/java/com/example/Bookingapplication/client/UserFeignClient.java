package com.example.Bookingapplication.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Bookingapplication.entity.User;

@FeignClient(name = "USERMANAGEMENT")
public interface UserFeignClient {

    @GetMapping("/users/id/{userId}")
    User getUserById(@PathVariable("userId") int userId);
}
