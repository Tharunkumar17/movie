package com.example.Bookingapplication.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.Bookingapplication.entity.Movie;

@FeignClient(name = "MOVIESERVICE")
public interface MovieFeignClient {

    @GetMapping("/movies/{movieId}")
    Movie getMovieById(@PathVariable("movieId") int movieId);
}

