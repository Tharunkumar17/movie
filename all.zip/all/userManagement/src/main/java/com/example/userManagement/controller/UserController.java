package com.example.userManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.userManagement.entity.User;
import com.example.userManagement.service.UserService;
@RequestMapping("/users")
@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	// 1.Get all users 
	@GetMapping("/all")
	public List<User> getAllUsers(){
		return userService.getAllUsers();
	}
	
	@GetMapping("id/{userId}")
    public User getUserWithIdUser(@PathVariable int userId) {
        return userService.getUserWithIdUser(userId);
    }
	
	
	// 2.get user details by mobile no.
	@GetMapping("/mobile/{mobileNo}")
    public User getUserByMobileNo(@PathVariable long mobileNo) {
        User user = userService.getUserByMobileNo(mobileNo);
        if(user != null) {
        	return user;
        } else{
            return null;
        }
	}

	
	// 3.add user Details 
	@PostMapping("/add")
	public User createUser(@RequestBody User user) {
		return userService.createUser(user);
	}

	
	// 4.Delete user Details
	@DeleteMapping("/{userId}")
    public void deleteUserDetails(@PathVariable int userId) {
        userService.deleteUserDetails(userId);
    }
}
